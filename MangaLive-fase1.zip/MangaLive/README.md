# MangaLive (en desarrollo — Fase 1)

Lector Android de manga y documentos japoneses con traducción JA→ES. Licencia Apache 2.0.

## Estado real (Fase 1)
**Implementado, SIN compilar ni probar todavía:**
- Selector nativo de archivos (SAF), recientes, última página recordada.
- Lectura de JPG/JPEG/PNG/WEBP, PDF (PdfRenderer) y CBZ/ZIP.
- Navegación anterior/siguiente, ir a página, zoom (pellizco, doble toque = reiniciar),
  ajustar a pantalla/ancho, girar pantalla.
- Ventana de memoria: página actual + 1 anterior + 2 siguientes, caché LRU (48 MB), cancelación y
  deduplicación de cargas. La imagen original nunca se modifica (solo se dibuja con transformaciones).

**No implementado:** EPUB, TXT, CBR, OCR, traducción, capa de traducciones, ajustes, modo flotante, Room.
Los botones de esas funciones aparecen deshabilitados.

## Compilar
- Android Studio (Ladybug o superior): Open → esperar sync → Build > Build APK(s).
- Sin instalar nada: sube el proyecto a GitHub; la Action `.github/workflows/build.yml`
  genera la APK debug como artefacto.
- El wrapper de Gradle (`gradlew`) no está incluido; Android Studio lo regenera.

## Dependencias
AndroidX Core/Activity/Lifecycle, Jetpack Compose + Material3, Kotlin Coroutines (todas Apache 2.0).

## Limitaciones conocidas
- CBZ se copia entero al caché interno para acceso aleatorio (se borra al cerrar).
- Sin icono de lanzador propio aún; textos de UI en código (pendiente moverlos a strings.xml).
- Release sin firma: configura tu keystore antes de distribuir.
