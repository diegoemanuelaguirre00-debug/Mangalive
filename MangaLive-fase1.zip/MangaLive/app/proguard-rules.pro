# Release sin firma: configura tu keystore antes de distribuir.
