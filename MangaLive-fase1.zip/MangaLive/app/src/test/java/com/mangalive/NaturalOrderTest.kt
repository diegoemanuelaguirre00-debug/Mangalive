package com.mangalive

import com.mangalive.data.reader.NaturalOrder
import org.junit.Assert.assertEquals
import org.junit.Test

class NaturalOrderTest {
    @Test
    fun sortsNumbersNaturally() {
        val sorted = listOf("p10.jpg", "p2.jpg", "p1.jpg", "p01a.jpg").sortedWith(NaturalOrder)
        assertEquals(listOf("p1.jpg", "p01a.jpg", "p2.jpg", "p10.jpg"), sorted)
    }
}
