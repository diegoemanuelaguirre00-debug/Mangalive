package com.mangalive.data.reader

/** Orden natural: "p2.jpg" < "p10.jpg". */
object NaturalOrder : Comparator<String> {
    private val chunk = Regex("\\d+|\\D+")

    override fun compare(a: String, b: String): Int {
        val ca = chunk.findAll(a.lowercase()).map { it.value }.toList()
        val cb = chunk.findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(ca.size, cb.size)) {
            val x = ca[i]; val y = cb[i]
            val nx = x.toBigIntegerOrNull(); val ny = y.toBigIntegerOrNull()
            val r = if (nx != null && ny != null) nx.compareTo(ny) else x.compareTo(y)
            if (r != 0) return r
        }
        return ca.size.compareTo(cb.size)
    }
}
