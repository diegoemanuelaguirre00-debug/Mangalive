package com.mangalive.ui.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mangalive.data.prefs.ReaderPrefs

private val MIME_TYPES = arrayOf(
    "image/jpeg", "image/png", "image/webp", "application/pdf",
    "application/zip", "application/x-cbz", "application/vnd.comicbook+zip",
    "application/octet-stream"
)

@Composable
fun HomeScreen(onOpen: (Uri) -> Unit) {
    val context = LocalContext.current
    val recents = remember { ReaderPrefs(context).recents() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            onOpen(uri)
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("MangaLive", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Medium)
        Text(
            "Lector de manga y documentos japoneses",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { picker.launch(MIME_TYPES) }) { Text("Abrir archivo") }
        Spacer(Modifier.height(8.dp))
        // Funciones aún no implementadas: se muestran deshabilitadas, no simuladas.
        OutlinedButton(onClick = {}, enabled = false) { Text("Modo flotante (pendiente)") }
        OutlinedButton(onClick = {}, enabled = false) { Text("Ajustes (pendiente)") }
        Spacer(Modifier.height(24.dp))
        Text("Recientes", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        if (recents.isEmpty()) {
            Text("Aún no has abierto documentos.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn {
                items(recents) { doc ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(Uri.parse(doc.uri)) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { Text(doc.name, maxLines = 1) }
                    HorizontalDivider()
                }
            }
        }
    }
}
