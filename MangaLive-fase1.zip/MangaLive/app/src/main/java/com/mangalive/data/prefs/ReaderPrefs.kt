package com.mangalive.data.prefs

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentDoc(val uri: String, val name: String)

/** Última página por documento y lista de recientes. (Se migrará a Room en la Fase 3.) */
class ReaderPrefs(context: Context) {
    private val sp = context.getSharedPreferences("mangalive_reader", Context.MODE_PRIVATE)

    fun lastPage(uri: Uri): Int = sp.getInt("last:$uri", 0)
    fun setLastPage(uri: Uri, page: Int) = sp.edit().putInt("last:$uri", page).apply()

    fun recents(): List<RecentDoc> = runCatching {
        val arr = JSONArray(sp.getString("recents", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it); RecentDoc(o.getString("uri"), o.getString("name"))
        }
    }.getOrDefault(emptyList())

    fun addRecent(uri: Uri, name: String) {
        val list = (listOf(RecentDoc(uri.toString(), name)) + recents().filter { it.uri != uri.toString() }).take(10)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        sp.edit().putString("recents", arr.toString()).apply()
    }
}
