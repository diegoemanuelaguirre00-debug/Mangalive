package com.mangalive.ui.reader

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangalive.data.prefs.ReaderPrefs
import com.mangalive.data.reader.DocumentOpener
import com.mangalive.data.reader.PageBitmapCache
import com.mangalive.domain.PageSource
import com.mangalive.domain.UnsupportedFormatException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ReaderUiState(
    val title: String = "",
    val pageCount: Int = 0,
    val pageIndex: Int = 0,
    val bitmap: Bitmap? = null,
    val loading: Boolean = true,
    val error: String? = null
)

/**
 * Ventana de memoria: página actual + 1 anterior + 2 siguientes. Lo demás se expulsa.
 * Las cargas en curso se deduplican (un Deferred por página) y se cancelan al salir de la ventana.
 */
class ReaderViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = ReaderPrefs(app)
    private val cache = PageBitmapCache(maxBytes = 48 * 1024 * 1024)
    private val pending = mutableMapOf<Int, Deferred<Bitmap>>() // solo hilo principal
    private var source: PageSource? = null
    private var currentUri: Uri? = null
    private var navJob: Job? = null

    private val _state = MutableStateFlow(ReaderUiState())
    val state: StateFlow<ReaderUiState> = _state.asStateFlow()

    fun open(uri: Uri) {
        if (uri == currentUri && source != null) return
        close()
        currentUri = uri
        _state.value = ReaderUiState(loading = true)
        navJob = viewModelScope.launch {
            try {
                val src = withContext(Dispatchers.IO) { DocumentOpener.open(getApplication(), uri) }
                source = src
                prefs.addRecent(uri, src.displayName)
                _state.update { it.copy(title = src.displayName, pageCount = src.pageCount) }
                showPage(prefs.lastPage(uri).coerceIn(0, src.pageCount - 1))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.value = ReaderUiState(loading = false, error = friendly(e))
            }
        }
    }

    fun goTo(index: Int) {
        val src = source ?: return
        val i = index.coerceIn(0, src.pageCount - 1)
        navJob?.cancel()
        navJob = viewModelScope.launch {
            try {
                showPage(i)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.update { it.copy(loading = false, error = friendly(e)) }
            }
        }
    }

    fun next() = goTo(_state.value.pageIndex + 1)
    fun previous() = goTo(_state.value.pageIndex - 1)

    private suspend fun showPage(i: Int) {
        val count = source?.pageCount ?: return
        _state.update { it.copy(pageIndex = i, loading = cache.get(i) == null, error = null) }
        trimTo(i - 1..i + 2)
        val bmp = getPage(i)
        _state.update { it.copy(bitmap = bmp, loading = false) }
        currentUri?.let { prefs.setLastPage(it, i) }
        listOf(i + 1, i - 1, i + 2).filter { it in 0 until count }.forEach(::prefetch)
    }

    private fun prefetch(i: Int) {
        if (cache.get(i) != null || pending.containsKey(i)) return
        viewModelScope.launch { runCatching { getPage(i) } }
    }

    private suspend fun getPage(i: Int): Bitmap {
        cache.get(i)?.let { return it }
        val src = source ?: throw IllegalStateException("Documento cerrado")
        val job = pending.getOrPut(i) {
            viewModelScope.async(Dispatchers.IO) {
                src.loadPage(i, MAX_DIMENSION).also { cache.put(i, it) }
            }
        }
        try {
            return job.await()
        } finally {
            if (job.isCompleted) pending.remove(i)
        }
    }

    private fun trimTo(window: IntRange) {
        pending.keys.filter { it !in window }.forEach { pending.remove(it)?.cancel() }
        cache.keys().filter { it !in window }.forEach(cache::remove)
    }

    fun close() {
        navJob?.cancel()
        pending.values.forEach { it.cancel() }
        pending.clear()
        cache.clear()
        source?.close()
        source = null
        currentUri = null
    }

    override fun onCleared() = close()

    private fun friendly(e: Throwable): String = when (e) {
        is UnsupportedFormatException -> e.message ?: "Formato no compatible"
        is SecurityException -> "No se puede abrir: el PDF está protegido o falta permiso de acceso."
        is OutOfMemoryError -> "Memoria insuficiente para esta página."
        else -> "No se pudo abrir el archivo: ${e.message ?: e.javaClass.simpleName}"
    }

    companion object {
        /** Lado mayor máximo del bitmap decodificado (~2048x1450 ≈ 12 MB por página). */
        const val MAX_DIMENSION = 2048
    }
}
