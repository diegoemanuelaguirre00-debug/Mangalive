package com.mangalive

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.mangalive.ui.home.HomeScreen
import com.mangalive.ui.reader.ReaderScreen
import com.mangalive.ui.theme.MangaLiveTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MangaLiveTheme { MangaLiveApp() } }
    }
}

@Composable
private fun MangaLiveApp() {
    var openUri by rememberSaveable { mutableStateOf<String?>(null) }
    Surface(modifier = Modifier.safeDrawingPadding()) {
        val current = openUri
        if (current == null) {
            HomeScreen(onOpen = { openUri = it.toString() })
        } else {
            BackHandler { openUri = null }
            ReaderScreen(uri = Uri.parse(current), onBack = { openUri = null })
        }
    }
}
