package com.mangalive.data.reader

import android.graphics.Bitmap
import android.util.LruCache

/**
 * LRU limitado por bytes. No se llama a recycle(): Compose podría estar dibujando
 * el bitmap; el GC lo libera cuando nadie lo referencia.
 */
class PageBitmapCache(maxBytes: Int) {
    private val lru = object : LruCache<Int, Bitmap>(maxBytes) {
        override fun sizeOf(key: Int, value: Bitmap) = value.allocationByteCount
    }
    fun get(page: Int): Bitmap? = lru.get(page)
    fun put(page: Int, bmp: Bitmap) { lru.put(page, bmp) }
    fun remove(page: Int) { lru.remove(page) }
    fun keys(): Set<Int> = lru.snapshot().keys
    fun clear() = lru.evictAll()
}
