package com.mangalive.ui.reader

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ReaderScreen(uri: Uri, onBack: () -> Unit, vm: ReaderViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val activity = LocalContext.current as? Activity
    var fitWidth by rememberSaveable { mutableStateOf(false) }
    var showGoTo by remember { mutableStateOf(false) }

    LaunchedEffect(uri) { vm.open(uri) }
    DisposableEffect(Unit) {
        onDispose {
            vm.close()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Inicio") }
            Text(state.title, Modifier.weight(1f), maxLines = 1, style = MaterialTheme.typography.titleSmall)
            TextButton(onClick = { fitWidth = !fitWidth }) { Text(if (fitWidth) "Ancho" else "Pantalla") }
            TextButton(onClick = {
                val landscape = activity?.resources?.configuration?.orientation == Configuration.ORIENTATION_LANDSCAPE
                activity?.requestedOrientation =
                    if (landscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }) { Text("Girar") }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            state.bitmap?.let { ZoomableImage(it, fitWidth, Modifier.fillMaxSize()) }
            if (state.loading) CircularProgressIndicator()
            state.error?.let {
                Text(it, Modifier.padding(24.dp), color = MaterialTheme.colorScheme.error)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = vm::previous, enabled = state.pageIndex > 0) { Text("‹ Anterior") }
            TextButton(onClick = { showGoTo = true }, enabled = state.pageCount > 0) {
                Text("${state.pageIndex + 1} / ${state.pageCount}")
            }
            OutlinedButton(
                onClick = vm::next,
                enabled = state.pageIndex < state.pageCount - 1
            ) { Text("Siguiente ›") }
        }
    }

    if (showGoTo) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGoTo = false },
            title = { Text("Ir a la página") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    singleLine = true,
                    label = { Text("1 – ${state.pageCount}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.let { vm.goTo(it - 1) }
                    showGoTo = false
                }) { Text("Ir") }
            },
            dismissButton = { TextButton(onClick = { showGoTo = false }) { Text("Cancelar") } }
        )
    }
}
