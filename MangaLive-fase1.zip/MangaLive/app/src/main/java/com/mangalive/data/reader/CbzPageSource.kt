package com.mangalive.data.reader

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.mangalive.domain.PageSource
import java.io.File
import java.io.IOException
import java.util.zip.ZipFile

/**
 * ZIP/CBZ. ZipFile necesita acceso aleatorio, así que el archivo se copia una vez al caché
 * interno de la app (se borra al cerrar). Solo se descomprime la página pedida.
 */
class CbzPageSource private constructor(
    private val file: File,
    private val zip: ZipFile,
    private val entries: List<String>,
    override val displayName: String
) : PageSource {
    @Volatile private var closed = false
    override val pageCount: Int = entries.size

    override fun loadPage(index: Int, maxDimension: Int): Bitmap {
        check(!closed) { "Documento cerrado" }
        val entry = zip.getEntry(entries[index]) ?: throw IOException("Página no encontrada")
        return BitmapDecoder.decode(maxDimension) { zip.getInputStream(entry) }
    }

    override fun close() {
        closed = true
        runCatching { zip.close() }
        file.delete()
    }

    companion object {
        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

        fun create(context: Context, uri: Uri, name: String): CbzPageSource {
            val dir = File(context.cacheDir, "archives").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() } // limpia restos de sesiones anteriores
            val file = File(dir, "current.zip")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    file.outputStream().use { input.copyTo(it) }
                } ?: throw IOException("No se pudo abrir el archivo")
                val zip = ZipFile(file)
                val names = zip.entries().asSequence()
                    .filter { !it.isDirectory }
                    .map { it.name }
                    .filter { n ->
                        val base = n.substringAfterLast('/')
                        !n.startsWith("__MACOSX") && !base.startsWith(".") &&
                            base.substringAfterLast('.', "").lowercase() in IMAGE_EXT
                    }
                    .sortedWith(NaturalOrder)
                    .toList()
                if (names.isEmpty()) {
                    zip.close()
                    throw IOException("El archivo no contiene imágenes compatibles")
                }
                return CbzPageSource(file, zip, names, name)
            } catch (e: Throwable) {
                file.delete()
                throw e
            }
        }
    }
}
