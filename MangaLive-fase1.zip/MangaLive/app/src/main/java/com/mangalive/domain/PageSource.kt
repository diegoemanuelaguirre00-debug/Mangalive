package com.mangalive.domain

import android.graphics.Bitmap
import java.io.Closeable

/** Fuente de páginas de un documento. Cada implementación carga UNA página a la vez. */
interface PageSource : Closeable {
    val displayName: String
    val pageCount: Int

    /** Devuelve la página [index] (0-based) con su lado mayor limitado a [maxDimension] px. */
    fun loadPage(index: Int, maxDimension: Int): Bitmap
}

class UnsupportedFormatException(message: String) : Exception(message)
