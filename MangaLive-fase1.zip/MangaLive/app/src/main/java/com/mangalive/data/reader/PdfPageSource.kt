package com.mangalive.data.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.mangalive.domain.PageSource
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

/** PdfRenderer solo admite una página abierta a la vez: todo el acceso va sincronizado. */
class PdfPageSource(
    context: Context,
    uri: Uri,
    override val displayName: String
) : PageSource {
    private val lock = Any()
    private var closed = false
    private val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r")
        ?: throw IOException("No se pudo abrir el archivo")
    private val renderer: PdfRenderer = try {
        PdfRenderer(pfd)
    } catch (e: Throwable) {
        pfd.close()
        throw e // SecurityException = PDF protegido; IOException = dañado
    }
    override val pageCount: Int = renderer.pageCount

    override fun loadPage(index: Int, maxDimension: Int): Bitmap = synchronized(lock) {
        check(!closed) { "Documento cerrado" }
        renderer.openPage(index).use { page ->
            val scale = maxDimension.toFloat() / max(page.width, page.height)
            val w = (page.width * scale).roundToInt().coerceAtLeast(1)
            val h = (page.height * scale).roundToInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(bmp).drawColor(Color.WHITE) // el PDF se renderiza sobre transparente
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        }
    }

    override fun close() = synchronized(lock) {
        if (!closed) {
            closed = true
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
        Unit
    }
}
