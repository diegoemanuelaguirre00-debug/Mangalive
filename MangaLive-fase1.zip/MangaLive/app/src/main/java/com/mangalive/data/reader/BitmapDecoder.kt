package com.mangalive.data.reader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.IOException
import java.io.InputStream
import kotlin.math.max
import kotlin.math.roundToInt

object BitmapDecoder {
    /** Decodifica con submuestreo para no cargar más píxeles de los necesarios. */
    fun decode(maxDimension: Int, open: () -> InputStream?): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("Imagen dañada o formato no reconocido")
        }
        val longest = max(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (longest / (sample * 2) >= maxDimension) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = open()?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("No se pudo decodificar la imagen")

        val dec = max(decoded.width, decoded.height)
        if (dec <= maxDimension) return decoded
        val f = maxDimension.toFloat() / dec
        val scaled = Bitmap.createScaledBitmap(
            decoded, (decoded.width * f).roundToInt().coerceAtLeast(1),
            (decoded.height * f).roundToInt().coerceAtLeast(1), true
        )
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }
}
