package com.mangalive.ui.reader

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import kotlin.math.max
import kotlin.math.min

/**
 * Muestra el bitmap SIN modificarlo (solo transformaciones de dibujo con graphicsLayer).
 * Esta será la "Capa 1"; la capa de traducciones se apilará encima en la Fase 4.
 */
@Composable
fun ZoomableImage(bitmap: Bitmap, fitWidth: Boolean, modifier: Modifier = Modifier) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    BoxWithConstraints(modifier.clipToBounds()) {
        val boxW = constraints.maxWidth.toFloat()
        val boxH = constraints.maxHeight.toFloat()
        val fw = boxW / bitmap.width
        val fh = boxH / bitmap.height
        val fitScale = min(fw, fh)
        val base = if (fitWidth) fw / fitScale else 1f // factor extra sobre "ajustar a pantalla"

        fun maxPan(zoom: Float): Offset {
            val s = base * zoom
            return Offset(
                max(0f, (bitmap.width * fitScale * s - boxW) / 2f),
                max(0f, (bitmap.height * fitScale * s - boxH) / 2f)
            )
        }
        fun clamp(o: Offset, zoom: Float): Offset {
            val m = maxPan(zoom)
            return Offset(o.x.coerceIn(-m.x, m.x), o.y.coerceIn(-m.y, m.y))
        }
        // En "ajustar al ancho" se empieza viendo la parte superior de la página.
        fun initialOffset() = Offset(0f, if (fitWidth) maxPan(1f).y else 0f)

        var zoom by remember(bitmap, fitWidth, boxW, boxH) { mutableFloatStateOf(1f) }
        var offset by remember(bitmap, fitWidth, boxW, boxH) { mutableStateOf(initialOffset()) }

        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(bitmap, fitWidth) {
                    detectTapGestures(onDoubleTap = { zoom = 1f; offset = initialOffset() })
                }
                .pointerInput(bitmap, fitWidth) {
                    detectTransformGestures { _, pan, gestureZoom, _ ->
                        zoom = (zoom * gestureZoom).coerceIn(1f, 5f)
                        offset = clamp(offset + pan, zoom)
                    }
                }
                .graphicsLayer {
                    val s = base * zoom
                    scaleX = s; scaleY = s
                    translationX = offset.x; translationY = offset.y
                }
        )
    }
}
