package com.mangalive.data.reader

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.mangalive.domain.PageSource
import com.mangalive.domain.UnsupportedFormatException

/** Elige la implementación según extensión/MIME. Bloqueante: llamar desde Dispatchers.IO. */
object DocumentOpener {
    private val IMAGES = setOf("jpg", "jpeg", "png", "webp")

    fun open(context: Context, uri: Uri): PageSource {
        val name = queryName(context, uri) ?: "documento"
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = context.contentResolver.getType(uri).orEmpty()
        return when {
            ext in IMAGES || mime in setOf("image/jpeg", "image/png", "image/webp") ->
                ImagePageSource(context, uri, name)
            ext == "pdf" || mime == "application/pdf" -> PdfPageSource(context, uri, name)
            ext == "cbz" || ext == "zip" -> CbzPageSource.create(context, uri, name)
            else -> throw UnsupportedFormatException(
                "Formato no compatible todavía (.${ext.ifEmpty { "?" }}). " +
                    "Compatibles ahora: JPG, PNG, WEBP, PDF, CBZ/ZIP."
            )
        }
    }

    private fun queryName(context: Context, uri: Uri): String? =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull()
}
