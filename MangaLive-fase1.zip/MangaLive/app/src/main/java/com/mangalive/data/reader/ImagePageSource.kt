package com.mangalive.data.reader

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.mangalive.domain.PageSource

class ImagePageSource(
    private val context: Context,
    private val uri: Uri,
    override val displayName: String
) : PageSource {
    override val pageCount = 1

    override fun loadPage(index: Int, maxDimension: Int): Bitmap =
        BitmapDecoder.decode(maxDimension) { context.contentResolver.openInputStream(uri) }

    override fun close() {}
}
